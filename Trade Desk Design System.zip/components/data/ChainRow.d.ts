import React from "react";

export type PriceSource = "quote" | "bs";

/**
 * ChainRow — one strike row of the option chain (CALL │ STRIKE │ PUT).
 *
 * @startingPoint section="Data" subtitle="Option-chain strike row" viewport="280x200"
 */
export interface ChainRowProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Strike price. */
  strike: number;
  /** Call price. */
  call: number;
  /** Put price. */
  put: number;
  /** ATM row — amber highlight. */
  isAtm?: boolean;
  /** Pricing source per side; "bs" dims + tags `·m`. */
  callSource?: PriceSource;
  putSource?: PriceSource;
  onCall?: () => void;
  onPut?: () => void;
  onStrike?: () => void;
  disabled?: boolean;
}

export function ChainRow(props: ChainRowProps): JSX.Element;
