import React from "react";

/**
 * ChainRow — one strike row of the option chain: CALL │ STRIKE │ PUT.
 * Three centered columns (84 / 64 / 84) so calls/puts hug the strike.
 * 18px tall, 11px tabular. ATM row = amber left-border + lifted fill +
 * amber strike. Clicking a price fires onCall/onPut; the strike fires
 * onStrike (straddle when ATM). Prices tagged `·m` are model-priced.
 */
export function ChainRow({
  strike,
  call,
  put,
  isAtm = false,
  callSource = "quote",
  putSource = "quote",
  onCall,
  onPut,
  onStrike,
  disabled = false,
  style,
  ...rest
}) {
  const grid = "84px 64px 84px";
  const cell = (price, source, align, onClick) => {
    const dim = source === "bs";
    const dead = disabled || price <= 0;
    return (
      <button
        type="button"
        onClick={onClick}
        disabled={dead}
        style={{
          height: "100%",
          padding: "0 8px",
          textAlign: align,
          fontSize: 11,
          fontVariantNumeric: "tabular-nums",
          fontFamily: "var(--td-font-mono)",
          background: "transparent",
          border: "none",
          color: dim ? "var(--td-fg-secondary)" : "var(--td-fg-primary)",
          opacity: dead ? 0.3 : 1,
          cursor: dead ? "not-allowed" : "pointer",
          transition: "var(--td-transition-colors)",
        }}
      >
        {price.toFixed(2)}
        {source === "bs" && (
          <span style={{ color: "var(--td-fg-tertiary)", marginLeft: 2, fontSize: 8 }}>·m</span>
        )}
      </button>
    );
  };
  return (
    <div
      data-strike={strike}
      data-atm={isAtm || undefined}
      style={{
        display: "grid",
        gridTemplateColumns: grid,
        alignItems: "center",
        height: 18,
        fontSize: 11,
        fontVariantNumeric: "tabular-nums",
        borderBottom: "1px solid var(--td-border)",
        borderLeft: `2px solid ${isAtm ? "var(--td-amber)" : "transparent"}`,
        background: isAtm ? "var(--td-bg-1)" : "transparent",
        ...style,
      }}
      {...rest}
    >
      {cell(call, callSource, "right", onCall)}
      <button
        type="button"
        onClick={onStrike}
        disabled={disabled}
        style={{
          height: "100%",
          textAlign: "center",
          fontFamily: "var(--td-font-mono)",
          fontSize: 11,
          fontWeight: isAtm ? 500 : 400,
          borderLeft: "1px solid var(--td-border)",
          borderRight: "1px solid var(--td-border)",
          borderTop: "none",
          borderBottom: "none",
          background: "transparent",
          color: isAtm ? "var(--td-amber)" : "var(--td-fg-primary)",
          cursor: disabled ? "not-allowed" : "pointer",
          transition: "var(--td-transition-colors)",
        }}
      >
        {strike}
      </button>
      {cell(put, putSource, "left", onPut)}
    </div>
  );
}
