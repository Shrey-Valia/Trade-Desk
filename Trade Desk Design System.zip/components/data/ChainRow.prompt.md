One strike row of the option chain. Stack many inside a scroll container with a CALL/STRIKE/PUT column header above.

```jsx
<ChainRow strike={759} call={0.08} put={0.63} isAtm
  onCall={()=>buy('call',759)} onStrike={()=>buy('straddle',759)} onPut={()=>buy('put',759)} />
<ChainRow strike={760} call={0.04} put={1.76} callSource="bs" />
```

ATM row gets the amber left-border + lifted fill. `*Source="bs"` dims the price and tags it `·m` (model-priced). Center columns are fixed 84/64/84 so prices hug the strike.
