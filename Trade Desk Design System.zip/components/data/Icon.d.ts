import React from "react";

export type IconName = "chart" | "journal" | "analytics" | "watchlist" | "zerodte" | "settings";

/**
 * Icon — custom monoline glyph set, inherits currentColor.
 */
export interface IconProps extends React.SVGProps<SVGSVGElement> {
  /** Which glyph to render. */
  name: IconName;
  /** Square size in px. Default 20. */
  size?: number;
}

export function Icon(props: IconProps): JSX.Element;
