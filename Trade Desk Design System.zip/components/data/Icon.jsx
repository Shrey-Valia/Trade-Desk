import React from "react";

/**
 * Icon — the terminal's custom monoline set. 20×20, stroke 1.5,
 * currentColor (inherits the parent's color, e.g. amber when active).
 * Names mirror the left-rail glyphs.
 */
const PATHS = {
  chart: (
    <>
      <line x1="6" y1="3" x2="6" y2="17" />
      <rect x="4" y="6" width="4" height="7" fill="currentColor" />
      <line x1="14" y1="3" x2="14" y2="17" />
      <rect x="12" y="8" width="4" height="5" />
    </>
  ),
  journal: (
    <>
      <path d="M4 4h9a2 2 0 0 1 2 2v11H6a2 2 0 0 1-2-2V4z" />
      <line x1="7" y1="8" x2="12" y2="8" />
      <line x1="7" y1="11" x2="12" y2="11" />
      <line x1="7" y1="14" x2="10" y2="14" />
    </>
  ),
  analytics: (
    <>
      <line x1="3" y1="17" x2="17" y2="17" />
      <rect x="4" y="11" width="3" height="6" />
      <rect x="9" y="7" width="3" height="10" />
      <rect x="14" y="4" width="3" height="13" />
    </>
  ),
  watchlist: (
    <>
      <circle cx="4.5" cy="5.5" r="1" fill="currentColor" stroke="none" />
      <line x1="8" y1="5.5" x2="17" y2="5.5" />
      <circle cx="4.5" cy="10" r="1" fill="currentColor" stroke="none" />
      <line x1="8" y1="10" x2="17" y2="10" />
      <circle cx="4.5" cy="14.5" r="1" fill="currentColor" stroke="none" />
      <line x1="8" y1="14.5" x2="17" y2="14.5" />
    </>
  ),
  zerodte: (
    <>
      <line x1="4" y1="3" x2="16" y2="3" />
      <line x1="4" y1="17" x2="16" y2="17" />
      <path d="M5 3v3l5 4-5 4v3M15 3v3l-5 4 5 4v3" />
    </>
  ),
  settings: (
    <>
      <circle cx="10" cy="10" r="2.5" />
      <path d="M10 2.5v2M10 15.5v2M2.5 10h2M15.5 10h2M4.7 4.7l1.4 1.4M13.9 13.9l1.4 1.4M4.7 15.3l1.4-1.4M13.9 6.1l1.4-1.4" />
    </>
  ),
};

export function Icon({ name, size = 20, style, ...rest }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={style}
      {...rest}
    >
      {PATHS[name] ?? null}
    </svg>
  );
}
