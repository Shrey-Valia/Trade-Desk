Custom monoline icon set — inherits `currentColor`, so set color on the parent.

```jsx
<span style={{ color: "var(--td-amber)" }}><Icon name="chart" /></span>
<Icon name="settings" size={24} style={{ color: "var(--td-fg-secondary)" }} />
```

Names: `chart`, `journal`, `analytics`, `watchlist`, `zerodte`, `settings`. For glyphs outside this set, use Lucide (matching 1.5px stroke).
