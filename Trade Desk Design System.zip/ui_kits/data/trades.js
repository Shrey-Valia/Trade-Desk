/* Shared closed-trade ledger for the Journal + Analytics screens.
   Deterministic mock: 14 0DTE trades, ~50% win rate, avg win slightly
   over avg loss, net modestly positive, with a visible mid-record
   drawdown. Both screens derive everything from TRADES + aggregations,
   so the journal and analytics never disagree. */
(function () {
  // [date, dow, entryTime, exitTime, symbol, strategy, structure,
  //  entry$, exit$, qty, note, tags]
  const SPEC = [
    ["May 19", "Tue", "09:38", "10:12", "SPY", "long call", "756C", 0.85, 1.55, 4, "", []],
    ["May 19", "Tue", "11:05", "13:20", "NVDA", "long call", "880C", 1.10, 2.15, 4, "", []],
    ["May 20", "Wed", "09:45", "10:30", "QQQ", "long put", "478P", 1.20, 0.60, 4, "", []],
    ["May 21", "Thu", "10:10", "11:45", "SPY", "straddle", "754C / 754P", 2.30, 3.00, 5, "Planned vol expansion into the morning range break. Sized right, took profit at target.", ["planned", "good setup"]],
    ["May 22", "Fri", "13:00", "14:15", "IWM", "put spread", "224P / 220P", 1.20, 0.60, 3, "", []],
    ["May 26", "Tue", "09:50", "10:20", "SPY", "call spread", "755C / 758C", 1.00, 1.95, 2, "", []],
    ["May 27", "Wed", "09:40", "11:10", "QQQ", "long call", "480C", 1.40, 0.70, 5, "Chased the open after missing the first move. No setup, just FOMO. Should have waited.", ["FOMO", "broke rules"]],
    ["May 27", "Wed", "12:30", "14:00", "SPY", "long put", "753P", 1.30, 0.65, 4, "", []],
    ["May 28", "Thu", "10:00", "13:30", "NVDA", "iron condor", "860P/865P · 895C/900C", 1.50, 0.75, 4, "Held too long into the afternoon trying to make it back. Theta chewed the wings. Revenge.", ["revenge trade", "broke rules"]],
    ["May 29", "Fri", "09:35", "11:20", "AAPL", "long call", "232C", 1.20, 2.90, 3, "A+ trend day, clean setup off the open. Let it run, trailed the stop.", ["planned", "good setup"]],
    ["Jun 2", "Tue", "10:15", "11:00", "SPY", "long call", "757C", 1.00, 0.525, 4, "", []],
    ["Jun 3", "Wed", "09:55", "12:40", "QQQ", "straddle", "477C / 477P", 2.40, 3.00, 4, "", []],
    ["Jun 4", "Thu", "13:10", "14:30", "SPY", "put spread", "754P / 751P", 1.05, 0.50, 4, "Decent thesis, market chopped sideways. Clean loss, within plan.", ["planned"]],
    ["Jun 5", "Fri", "09:42", "11:15", "NVDA", "long call", "885C", 1.10, 2.20, 3, "", []],
  ];

  const greeksFor = (i, win) => ({
    delta: (0.42 + (i % 4) * 0.07).toFixed(2),
    theta: "−" + (38 + (i % 5) * 9).toFixed(0),
    gamma: (0.9 + (i % 3) * 0.4).toFixed(2),
    vega: (11 + (i % 4) * 2).toFixed(0),
  });

  const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };

  const TRADES = SPEC.map((s, i) => {
    const [date, dow, tin, tout, sym, strat, struct, entry, exit, qty, note, tags] = s;
    const pnl = Math.round((exit - entry) * 100 * qty);
    const win = pnl >= 0;
    const risk = entry * 100 * qty;               // debit at risk for these structures
    const retPct = ((exit - entry) / entry) * 100;
    const rMultiple = (exit - entry) / entry;     // R relative to debit risk
    const hold = toMin(tout) - toMin(tin);
    const hour = Number(tin.split(":")[0]);
    const bucket = hour < 10 || (hour === 10 && toMin(tin) < 630) ? "Open" : hour < 13 ? "Midday" : "Power hour";
    return {
      id: i + 1, date, dow, tin, tout, sym, strat, struct,
      entry, exit, qty, pnl, win, risk, retPct, rMultiple, hold, hour, bucket,
      greeks: greeksFor(i, win), note, tags,
    };
  });

  // ---- date-range membership (relative to "today" = Jun 5 in the mock) ----
  const WEEK = new Set(["Jun 2", "Jun 3", "Jun 4", "Jun 5"]);
  function inRange(t, range) {
    if (range === "All" || range === "Month") return true; // record started this month
    if (range === "Week") return WEEK.has(t.date);
    if (range === "Today") return t.date === "Jun 5";
    return true;
  }

  // ---- aggregations ----
  function summarize(trades) {
    const n = trades.length;
    const wins = trades.filter((t) => t.win);
    const losses = trades.filter((t) => !t.win);
    const net = trades.reduce((a, t) => a + t.pnl, 0);
    const grossWin = wins.reduce((a, t) => a + t.pnl, 0);
    const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnl, 0));
    const winRate = n ? (wins.length / n) * 100 : 0;
    const avgWin = wins.length ? grossWin / wins.length : 0;
    const avgLoss = losses.length ? grossLoss / losses.length : 0;
    const profitFactor = grossLoss ? grossWin / grossLoss : grossWin ? Infinity : 0;
    const expectancy = n ? net / n : 0;
    const avgHoldWin = wins.length ? Math.round(wins.reduce((a, t) => a + t.hold, 0) / wins.length) : 0;
    const avgHoldLoss = losses.length ? Math.round(losses.reduce((a, t) => a + t.hold, 0) / losses.length) : 0;
    return { n, wins: wins.length, losses: losses.length, net, grossWin, grossLoss, winRate, avgWin, avgLoss, profitFactor, expectancy, avgHoldWin, avgHoldLoss };
  }

  // cumulative equity points (in trade order), plus drawdown stats
  function equity(trades) {
    let cum = 0, peak = 0, maxDD = 0, ddStart = null, ddTrough = null;
    const pts = trades.map((t, i) => {
      cum += t.pnl;
      if (cum > peak) peak = cum;
      const dd = peak - cum;
      if (dd > maxDD) { maxDD = dd; ddTrough = i; }
      return { i, cum, peak, dd };
    });
    return { pts, maxDD };
  }

  function groupBy(trades, keyFn) {
    const map = new Map();
    trades.forEach((t) => {
      const k = keyFn(t);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(t);
    });
    return [...map.entries()].map(([k, ts]) => {
      const net = ts.reduce((a, t) => a + t.pnl, 0);
      const w = ts.filter((t) => t.win).length;
      return { key: k, net, n: ts.length, wins: w, winRate: (w / ts.length) * 100 };
    });
  }

  function streaks(trades) {
    let best = 0, worst = 0, cur = 0;
    trades.forEach((t) => {
      if (t.win) cur = cur > 0 ? cur + 1 : 1; else cur = cur < 0 ? cur - 1 : -1;
      best = Math.max(best, cur); worst = Math.min(worst, cur);
    });
    // current streak from the tail
    let tail = 0;
    for (let i = trades.length - 1; i >= 0; i--) {
      if (i === trades.length - 1) tail = trades[i].win ? 1 : -1;
      else if ((trades[i].win && tail > 0) || (!trades[i].win && tail < 0)) tail += trades[i].win ? 1 : -1;
      else break;
    }
    return { best, worst, current: tail };
  }

  const fmt = (v, signed) => {
    const s = signed ? (v > 0 ? "+" : v < 0 ? "−" : "") : v < 0 ? "−" : "";
    return s + "$" + Math.abs(Math.round(v)).toLocaleString("en-US");
  };
  const fmtHold = (m) => (m >= 60 ? Math.floor(m / 60) + "h " + (m % 60) + "m" : m + "m");

  window.TDJournal = {
    TRADES, inRange, summarize, equity, groupBy, streaks, fmt, fmtHold,
    MLL_TRAIL: 2000, // 50K combine trail distance (risk-panel reference)
    TIER: "50K",
  };
})();
